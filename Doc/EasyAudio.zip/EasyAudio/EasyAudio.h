/**
* @file Audio.h
*/
#ifndef EASY_AUDIO_H_INCLUDED
#define EASY_AUDIO_H_INCLUDED

class Audio
{
public:
  static bool Initialize();
  static void Finalize();
  static Audio& Get();

  // �I�[�f�B�I��Ԃ̍X�V
  void Update();

  // ���[�v�Đ�
  void PlayLoop(size_t playerId, const char* filename, float volume = 1.0f);
  void Stop(size_t playerId);
  void SetVolume(size_t playerId, float volume);
  float GetVolume(size_t playerId) const;

  // �P���Đ�
  void PlayOneShot(const char* filename, float volume = 1.0f);

  void SetMasterVolume(float volume);
  float GetMasterVolume() const;

private:
  Audio() = default;
  ~Audio() = default;
  Audio(const Audio&) = delete;
  Audio& operator=(const Audio&) = delete;
};

#endif // EASY_AUDIO_H_INCLUDED